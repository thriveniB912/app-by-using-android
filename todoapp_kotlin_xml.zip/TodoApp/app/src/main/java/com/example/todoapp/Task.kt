package com.example.todoapp

data class Task(
    val name: String,
    var isDone: Boolean = false
)
